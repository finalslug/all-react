function App() {
return <div className="App">All react</div>;
}

export default App;
