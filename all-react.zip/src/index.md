import React from "react";
import ReactDOM from "react-dom";
// import App from "./App";
// import Login from "./pages/Login/Login";
// import Main from "./pages/Main/Main";
import Routes from "./Routes";

// ReactDOM.render(<App />, document.getElementById("root"));
// ReactDOM.render(<Login />, document.getElementById("root"));
ReactDOM.render(<Routes />, document.getElementById("root"));
